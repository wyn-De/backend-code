const express = require('express')
const mysql = require('mysql2/promise')
const dotenv = require('dotenv')
const path = require('path')
const cors = require('cors') // 新增跨域，避免前端请求失败

dotenv.config()
const app = express()
const port = process.env.PORT || 3000

// 中间件
app.use(cors()) // 解决跨域
app.use(express.json())
app.use(express.static(path.join(__dirname, '../public')))

// ========== 1. 门诊数据库连接池（原有） ==========
const outpatientPool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  connectionLimit: 10,
  charset: 'utf8mb4'
})

// ========== 2. 住院数据库连接池（新增，适配11zy库） ==========
const hospitalPool = mysql.createPool({
  host: process.env.DB_HOSPITAL_HOST,
  user: process.env.DB_HOSPITAL_USER,
  password: process.env.DB_HOSPITAL_PASSWORD,
  database: process.env.DB_HOSPITAL_NAME,
  connectionLimit: 10,
  charset: 'utf8mb4'
})

// 首页路由
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'))
})

// ========== 门诊接口（原有，保留） ==========
// 门诊月份列表
app.get('/api/outpatient/months', async (req, res) => {
  try {
    const [targetTables] = await outpatientPool.execute(`SHOW TABLES LIKE 'hospital_outpatient_%'`)
    const monthList = []
    targetTables.forEach(table => {
      const tableName = Array.isArray(table) ? table[0] : Object.values(table)[0]
      if (tableName) {
        const parts = tableName.split('_')
        if (parts.length === 3 && /^\d{6}$/.test(parts[2])) {
          const yyyymm = parts[2]
          monthList.push({
            value: yyyymm,
            label: `${yyyymm.slice(0,4)}年${yyyymm.slice(4,6)}月`
          })
        }
      }
    })
    monthList.sort((a,b) => b.value.localeCompare(a.value))
    res.json({ code: 200, data: monthList, msg: '成功' })
  } catch (err) {
    console.error('获取门诊月份失败：', err)
    res.status(500).json({ code: 500, data: [], msg: '数据库查询失败' })
  }
})

// 门诊数据查询
app.get('/api/outpatient', async (req, res) => {
  const { month } = req.query
  if (!month || !/^\d{6}$/.test(month)) {
    return res.status(400).json({ code: 400, data: [], msg: '月份格式错误（需为YYYYMM）' })
  }
  const tableName = `hospital_outpatient_${month}`
  if (!/^hospital_outpatient_\d{6}$/.test(tableName)) {
    return res.status(400).json({ code: 400, data: [], msg: '表名格式错误' })
  }

  try {
    const sql = `
      SELECT \`医院\`, \`医院名称\`, DATE_FORMAT(\`月份\`, '%Y-%m-%d') AS \`月份\`,
             \`初诊\`, \`复诊\`, \`初复比例\`, \`挂号人次\`, \`门诊金额\`, \`均次费\`,
             \`平均处方\`, \`西成药\`, \`西成药占比\`, \`中草药\`, \`中草药占比\`,
             \`检查\`, \`检验\`, \`检查检验占比\`, \`中医理疗\`, \`理疗占比\`,
             \`总治疗收入\`, \`卫生材料\`, \`其他\`, \`理疗床数量\`, \`stat_month\`
      FROM \`${tableName}\`
    `
    const [rows] = await outpatientPool.execute(sql)
    const formattedData = rows.map(item => ({
      医院: item.医院 || 0,
      医院名称: item.医院名称 || '-',
      月份: item.月份 || '-',
      初诊: item.初诊 || 0,
      复诊: item.复诊 || 0,
      初复比例: item.初复比例 || 0,
      挂号人次: item.挂号人次 || 0,
      门诊金额: item.门诊金额 || 0,
      均次费: item.均次费 || 0,
      平均处方: item.平均处方 || 0,
      西成药: item.西成药 || 0,
      西成药占比: item.西成药占比 || 0,
      中草药: item.中草药 || 0,
      中草药占比: item.中草药占比 || 0,
      检查: item.检查 || 0,
      检验: item.检验 || 0,
      检查检验占比: item.检查检验占比 || 0,
      中医理疗: item.中医理疗 || 0,
      理疗占比: item.理疗占比 || 0,
      总治疗收入: item.总治疗收入 || 0,
      卫生材料: item.卫生材料 || 0,
      其他: item.其他 || 0,
      理疗床数量: item.理疗床数量 || 0,
      stat_month: item.stat_month || '-'
    }))
    res.json({ code: 200, data: formattedData, msg: '成功' })
  } catch (err) {
    console.error('门诊数据查询失败：', err)
    res.status(500).json({ code: 500, data: [], msg: '数据库查询失败' })
  }
})

// ========== 住院接口（新增，适配11zy库和hospital_inpatient_202511表） ==========
// 住院月份列表（自动识别hospital_inpatient_开头的表）
app.get('/api/hospital/months', async (req, res) => {
  try {
    const [targetTables] = await hospitalPool.execute(`SHOW TABLES LIKE 'hospital_inpatient_%'`)
    const monthList = []
    targetTables.forEach(table => {
      const tableName = Array.isArray(table) ? table[0] : Object.values(table)[0]
      if (tableName) {
        const parts = tableName.split('_')
        if (parts.length === 3 && /^\d{6}$/.test(parts[2])) {
          const yyyymm = parts[2]
          monthList.push({
            value: yyyymm,
            label: `${yyyymm.slice(0,4)}年${yyyymm.slice(4,6)}月`
          })
        }
      }
    })
    monthList.sort((a,b) => b.value.localeCompare(a.value))
    res.json({ code: 200, data: monthList, msg: '成功' })
  } catch (err) {
    console.error('获取住院月份失败：', err)
    res.status(500).json({ code: 500, data: [], msg: '数据库查询失败' })
  }
})

// 住院数据查询（适配你提供的所有住院表字段）
app.get('/api/hospital', async (req, res) => {
  const { month } = req.query
  if (!month || !/^\d{6}$/.test(month)) {
    return res.status(400).json({ code: 400, data: [], msg: '月份格式错误（需为YYYYMM）' })
  }
  const tableName = `hospital_inpatient_${month}`
  if (!/^hospital_inpatient_\d{6}$/.test(tableName)) {
    return res.status(400).json({ code: 400, data: [], msg: '表名格式错误' })
  }

  try {
    // 适配你提供的住院表所有字段
    const sql = `
      SELECT 
        \`医院\`, \`医院名称\`, \`总床位数\`, \`实际占床\`, \`平均床位\`,
        \`床日均收入\`, \`床位使用率\`, \`总收入\`, \`自费收入\`, \`医保收入\`,
        \`医保日均\`, \`西药\`, \`中成药\`, \`中草药\`, \`康复\`, \`中医\`,
        \`治疗\`, \`检查\`, \`摄片\`, \`检验\`, \`其他\`, \`西药占比\`,
        \`成药占比\`, \`西成占比\`, \`草药占比\`, \`药占比\`, \`西康占比\`,
        \`中康占比\`, \`康复占比\`, \`总治疗占比\`, \`检查占比\`, \`摄片占比\`,
        \`检查摄片占比\`, \`检验费占比\`, \`检查检验占比\`, \`stat_month\`
      FROM \`${tableName}\`
    `
    const [rows] = await hospitalPool.execute(sql)
    // 格式化住院数据（空值转0/-，和门诊逻辑一致）
    const formattedData = rows.map(item => ({
      医院: item.医院 || '-',
      医院名称: item.医院名称 || '-',
      总床位数: item.总床位数 || 0,
      实际占床: item.实际占床 || 0,
      平均床位: item.平均床位 || 0,
      床日均收入: item.床日均收入 || 0,
      床位使用率: item.床位使用率 || 0,
      总收入: item.总收入 || 0,
      自费收入: item.自费收入 || 0,
      医保收入: item.医保收入 || 0,
      医保日均: item.医保日均 || 0,
      西药: item.西药 || 0,
      中成药: item.中成药 || 0,
      中草药: item.中草药 || 0,
      康复: item.康复 || 0,
      中医: item.中医 || 0,
      治疗: item.治疗 || 0,
      检查: item.检查 || 0,
      摄片: item.摄片 || 0,
      检验: item.检验 || 0,
      其他: item.其他 || 0,
      西药占比: item.西药占比 || 0,
      成药占比: item.成药占比 || 0,
      西成占比: item.西成占比 || 0,
      草药占比: item.草药占比 || 0,
      药占比: item.药占比 || 0,
      西康占比: item.西康占比 || 0,
      中康占比: item.中康占比 || 0,
      康复占比: item.康复占比 || 0,
      总治疗占比: item.总治疗占比 || 0,
      检查占比: item.检查占比 || 0,
      摄片占比: item.摄片占比 || 0,
      检查摄片占比: item.检查摄片占比 || 0,
      检验费占比: item.检验费占比 || 0,
      检查检验占比: item.检查检验占比 || 0,
      stat_month: item.stat_month || '-'
    }))
    res.json({ code: 200, data: formattedData, msg: '成功' })
  } catch (err) {
    console.error('住院数据查询失败：', err)
    res.status(500).json({ code: 500, data: [], msg: '数据库查询失败' })
  }
})

// 启动服务
app.listen(port, () => {
  console.log(`✅ 后端服务启动成功：http://localhost:${port}`)
})